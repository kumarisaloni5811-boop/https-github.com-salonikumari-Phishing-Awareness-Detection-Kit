const questions=[
 {q:"Which is a common phishing warning sign?",o:["Unexpected urgency","A normal saved bookmark","A trusted offline document"],a:0},
 {q:"What should you do with an unexpected login link?",o:["Click immediately","Verify through the official app/site","Forward it to friends"],a:1},
 {q:"Should you share an OTP with someone who asks over a message?",o:["Yes","Only if they sound official","No"],a:2},
 {q:"What does MFA provide?",o:["An additional verification factor","Free internet","A longer email address"],a:0},
 {q:"What is a safer way to verify a bank message?",o:["Use the link in the message","Contact the bank using an official channel","Reply with your password"],a:1}
];

function checkURL(){
 const raw=document.getElementById("urlInput").value.trim();
 const box=document.getElementById("result");
 if(!raw){box.textContent="Please enter an example URL.";return;}
 let flags=[];
 try{
   const u=new URL(raw);
   if(u.protocol!=="https:") flags.push("The URL does not use HTTPS.");
   const host=u.hostname.toLowerCase();
   if(host.includes("@")) flags.push("The hostname contains an unusual character.");
   if(host.split(".").length>3) flags.push("The domain has many subdomains.");
   if(host.includes("login")||host.includes("verify")||host.includes("secure")) flags.push("The domain contains common lure words.");
   if(host.endsWith(".test")||host.endsWith(".example")) flags.push("This is a reserved example/test domain.");
   box.innerHTML=flags.length
    ? "⚠️ <strong>Potential warning signs:</strong><ul>"+flags.map(x=>"<li>"+x+"</li>").join("")+"</ul>"
    : "ℹ️ No simple warning sign was detected by this educational checker. Still verify the website independently.";
 }catch(e){box.textContent="⚠️ This does not look like a valid URL. Use an example such as https://example.test"; }
}

function renderQuiz(){
 const box=document.getElementById("quizBox");
 box.innerHTML=questions.map((x,i)=>`<fieldset><legend>${i+1}. ${x.q}</legend>`+
 x.o.map((opt,j)=>`<label><input type="radio" name="q${i}" value="${j}"> ${opt}</label>`).join("")+
 "</fieldset>").join("");
}
function submitQuiz(){
 let score=0,answered=0;
 questions.forEach((x,i)=>{const r=document.querySelector(`input[name="q${i}"]:checked`);if(r){answered++;if(+r.value===x.a)score++;}});
 document.getElementById("score").innerHTML=`<strong>Score: ${score}/${questions.length}</strong> — ${answered<questions.length?"Please answer all questions for a complete attempt.":"Good job! Review any incorrect answers and remember: verify independently."}`;
}
renderQuiz();