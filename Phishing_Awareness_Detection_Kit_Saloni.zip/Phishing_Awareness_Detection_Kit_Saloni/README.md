# Phishing Awareness & Detection Kit

An educational, responsive web project that teaches users how to identify and avoid common phishing attempts.

## Features
- What phishing is and common techniques
- Warning signs in suspicious messages
- Safe educational URL checker (local only; does not visit URLs)
- Fake-login/social-engineering awareness
- Password and MFA safety guidance
- Three harmless practice scenarios
- Reporting and response steps
- Five-question interactive quiz
- No real passwords, credentials, or personal information are collected

## Run locally
Open `index.html` in a modern browser.

## GitHub Pages
Repository Settings → Pages → Deploy from branch → `main` → `/ (root)` → Save.

## Resources
CISA Cybersecurity Resources, OWASP Web Security Resources, Google Safety Center.

## Safety
This project is strictly educational. Do not enter real passwords, OTPs, API keys, or personal information into the demo.
